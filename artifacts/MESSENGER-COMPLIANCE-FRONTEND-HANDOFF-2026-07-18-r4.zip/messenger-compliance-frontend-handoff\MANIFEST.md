# Package Manifest

## Contracts

- `contracts/MESSENGER_COMPLIANCE_IMPLEMENTATION.md`
  - authoritative V1 backend, security, DTO, route, UI, and E2E contract
- `BACKEND_INTEGRATION_STATUS.md`
  - frozen backend ownership, operator apply order, verification evidence, and
    the explicitly separate IAM follow-up

## Frontend

- `frontend/MESSENGER_COMPLIANCE_FRONTEND_IMPLEMENTATION.md`
  - component architecture, API hooks, state matrix, styling, tests, and
    integration order
- `frontend/MESSENGER_COMPLIANCE_FRONTEND_HANDOFF_CHECKLIST.md`
  - execution and completion checklist

## Subagent

- `subagent/MESSENGER_COMPLIANCE_FRONTEND_SUBAGENT_PROMPT.md`
  - ready-to-paste Claude frontend subagent prompt and parent-agent usage steps

## Mockup

- `mockup/index.html`
  - interactive static mockup
- `mockup/previews/compliance-v1-preview.png`
  - Conversations view
- `mockup/previews/compliance-v1-cases.png`
  - Cases view
- `mockup/previews/compliance-v1-access-log.png`
  - Access Log view

## Source provenance

Generated from the SIOMAC Codex worktree on 2026-07-18. Application/backend
source files are intentionally not duplicated in this package because they
would become stale; the implementation document names every live repo file the
frontend agent must inspect.
