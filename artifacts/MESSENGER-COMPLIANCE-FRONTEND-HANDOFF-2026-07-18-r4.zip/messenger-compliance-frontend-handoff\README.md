# SIOMAC Messenger Compliance V1 - Frontend Handoff

This package is the complete frontend handoff for implementing the approved
Messenger Compliance V1 release while a separate agent builds the backend.

## Start here

1. Read `contracts/MESSENGER_COMPLIANCE_IMPLEMENTATION.md`.
2. Read `BACKEND_INTEGRATION_STATUS.md`.
3. Read `frontend/MESSENGER_COMPLIANCE_FRONTEND_IMPLEMENTATION.md`.
4. Open `mockup/index.html`.
5. Read `subagent/MESSENGER_COMPLIANCE_FRONTEND_SUBAGENT_PROMPT.md`.
6. Use `frontend/MESSENGER_COMPLIANCE_FRONTEND_HANDOFF_CHECKLIST.md` as the
   completion gate.

## Mockup views

Open these URLs after serving the package directory or opening the HTML file:

- Conversations: `mockup/index.html`
- Cases: `mockup/index.html?view=cases`
- Access Log: `mockup/index.html?view=access-log`

The PNG files in `mockup/previews/` show the three primary states.

## Parallel-agent rule

The backend and frontend agents must use separate worktrees.

- Backend owns shared DTOs, migrations, routes, services, permission hardening,
  exports, and backend E2E.
- Frontend owns frontend API hooks, Messenger compliance components, styles,
  and component tests.
- `types/messagingCompliance.ts` is backend-owned and must be frozen before the
  frontend integrates live hooks.

Merge backend first, then rebase and integrate the frontend. Do not allow both
agents to edit the shared DTO file.

## Scope

Included:

- four backend-backed operational summary cards
- Cases
- Conversations
- Access Log
- approved, scoped, time-limited access
- immutable access evidence
- manual revoke and automatic-expiry UI
- PDF/JSON export UI
- required states, tests, and verification

Deferred:

- legal hold
- retention-policy management
- attachment evidence archives
- scheduled/background exports
- ticket linkage
- analytics and charts
- AI features
- message-body search

## Important

The mockup is an information-architecture and interaction reference. The
implementation must use the current Messenger shell, component system, theme
tokens, and safe message renderer. It must not copy the static mockup CSS as a
second design system.
