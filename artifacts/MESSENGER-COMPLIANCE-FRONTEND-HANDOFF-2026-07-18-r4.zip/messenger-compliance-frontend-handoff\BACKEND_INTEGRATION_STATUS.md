# Backend Integration Status

Status: backend source complete; live migration/E2E operator gate pending.

## Frozen contract

- Shared DTO: `types/messagingCompliance.ts`
- Routes: `netlify/functions/routes/communicationsCompliance.ts`
- Read models: `netlify/functions/lib/messaging/complianceService.ts`
- Transactions: migrations `433` and `434`
- Snapshot/export pipeline: migration `435` and
  `netlify/functions/lib/messaging/complianceExport.ts`
- Operational summary cards: migration `436` and
  `communications/compliance/summary/get`

The frontend may import the shared DTO but must not edit it.

## Required environment

Set `COMPLIANCE_EVIDENCE_PEPPER_V1` to a dedicated random value of at least 32
characters. Do not reuse the trusted-device pepper, JWT secret, or service-role
key.

## Operator apply order

1. Confirm the target is the intended development database.
2. Re-apply the current source definitions for migrations `330` and `340` if
   their hardened RPC definitions have not already been applied.
3. Apply migrations `432`, `433`, `434`, `435`, and `436` in order.
4. Reload the PostgREST schema cache.
5. Rebuild and restart the Netlify backend.
6. Run `communications` against the normal development database.
7. Run `communicationsCompliance` only against an isolated disposable E2E
   database with `E2E_DISPOSABLE_DB=1`.
8. Reset that database as its owner, re-apply migrations, run the suite a
   second time, and reset it again.

There is intentionally no service-role cleanup bypass for immutable compliance
evidence.

## Verified in source

- Backend TypeScript typecheck passes.
- Compliance renderer and critical-permission unit tests pass: 32/32.
- E2E route coverage gate passes with zero new gaps.
- E2E scripts pass Node syntax checks.
- Migrations `433`-`436` have balanced dollar quotes.

Live E2E is not claimed until the operator completes the disposable-database
sequence above.

## Accepted V1 constraint

Each export download requires live permission, an active scoped grant, fresh
step-up, integrity verification, and immutable evidence before the signed URL
is disclosed. A URL already issued may remain usable for the remainder of its
five-minute lifetime after a later revocation.

## Separate follow-up

The older generic, non-compliance critical-grant request path still deserves
its own atomicity hardening. It is outside this Messenger Compliance V1 slice
and is not presented as resolved by this handoff.
