# Messenger Compliance V1 - Frontend Handoff Checklist

## Before starting

- [ ] Backend owner confirmed.
- [ ] Frontend owner confirmed.
- [ ] Separate worktrees confirmed.
- [ ] `types/messagingCompliance.ts` committed and frozen.
- [ ] Exact route envelopes committed or documented.
- [ ] Parent and frontend contracts read.
- [ ] Mockup reviewed in Cases, Conversations, and Access Log modes.
- [ ] Four summary cards use `communications/compliance/summary/get`; no
      paginated-list or fixture-derived counts.

## Frontend build

- [ ] Existing Messenger shell retained.
- [ ] Cases view complete.
- [ ] New Case flow complete.
- [ ] Approve/reject/close flows complete.
- [ ] Conversations view complete.
- [ ] Dedicated compliance read route used.
- [ ] Read-only timeline complete.
- [ ] Right case/access rail complete.
- [ ] Grant revoke complete.
- [ ] Access Log complete.
- [ ] PDF/JSON export flow complete.
- [ ] Export creation and every download use the established step-up flow.
- [ ] Step-up flow integrated.
- [ ] Server-authored capabilities used for every command.
- [ ] Loading/empty/error states complete.
- [ ] Pending/expired/revoked states clear message content.
- [ ] Export requested/uploading/ready/failed states complete.
- [ ] Standard, rich, and action toasts used appropriately.

## Legacy removal

- [ ] `ComplianceBrowser` has no callers.
- [ ] `AccessThreadDialog` has no callers.
- [ ] `useRequestThreadAccess` has no callers.
- [ ] old compliance search hook has no callers.
- [ ] old record-export hook/route has no frontend callers.
- [ ] no ordinary thread-detail fallback in compliance mode.

## Verification

- [ ] Frontend typecheck passes.
- [ ] Focused frontend tests pass.
- [ ] Repository-required frontend tests pass.
- [ ] `communications` E2E passes.
- [ ] `communicationsCompliance` E2E passes twice on a disposable database,
      with an owner reset between runs.
- [ ] 1440px screenshot checked.
- [ ] 1600px screenshot checked.
- [ ] 1920px screenshot checked.
- [ ] Light theme checked.
- [ ] Dark theme checked if available.
- [ ] Keyboard/focus behavior checked.
- [ ] No sensitive content in Cases/Access Log payloads.
- [ ] No stale messages after scope change.
- [ ] Fixtures removed from production code.
- [ ] `docs/REPO_MAP.md` updated.

## Handoff evidence

- [ ] Frontend commit hash recorded.
- [ ] Changed-file list recorded.
- [ ] Contract deviations recorded.
- [ ] Test output summarized.
- [ ] Remaining operator steps recorded.
