# Claude Subagent Prompt - Messenger Compliance V1 Frontend

Paste the prompt below into the parent Claude session after the backend agent has
committed the frozen `types/messagingCompliance.ts` contract.

---

You are the frontend subagent for SIOMAC Messenger Compliance V1.

Work in an isolated worktree and branch. Do not share a working directory with
the backend agent. The parent agent will merge your result after backend DTOs
and routes are stable.

## Read first

1. `AGENTS.md`
2. `docs/module-contracts/MESSENGER_COMPLIANCE_IMPLEMENTATION.md`
3. `docs/module-contracts/MESSENGER_COMPLIANCE_FRONTEND_IMPLEMENTATION.md`
4. `mockups/messenger-compliance-v1/index.html`
5. Existing Messenger files named in the frontend implementation handoff

## Scope

Build only the Messenger Compliance V1 frontend:

- Cases
- Conversations
- Access Log
- New Case, decision, close, revoke, and export dialogs
- typed frontend API hooks
- UI states
- focused frontend tests

Preserve `MessagesWorkspace`, `QueueHeader`, the existing Compliance queue, and
the Messenger shell. `ComplianceView.tsx` remains the stable entry and should
render the new compliance workspace.

## Ownership

You own:

- `src/api/communicationsCompliance.ts`
- Messenger compliance components and compliance-specific CSS
- frontend tests for this UI
- removal of old compliance frontend components/hooks after cutover

You do not own and must not edit:

- Supabase migrations
- Netlify routes/services
- permission resolver code
- export generation
- backend E2E suites
- `types/messagingCompliance.ts`

Import shared DTOs from `types/messagingCompliance.ts`. If a field or capability
is missing, stop and report the exact mismatch. Do not create duplicate DTOs,
use `any`, cast around the contract, or infer permissions from roles.

## Non-negotiable behavior

- The current `AccessThreadDialog` self-grant flow must not survive cutover.
- Compliance conversation reads use only the dedicated compliance read route.
- Pending, rejected, expired, and revoked grants render no message content.
- Cases and Access Log contain metadata only.
- No composer, reactions, replies, forwarding, pinning, deletion, participant
  editing, or attachment download in compliance mode.
- Commands render only from server-authored capability flags.
- Export is case-scoped and PDF/JSON only. Both creation and every download use
  the application step-up flow.
- Keep one idempotency key for retries of the same logical mutation.
- Never accept and ignore a field or show a control backed by no real route.

## Parallel-work protocol

1. Confirm the frozen shared DTO commit hash with the parent agent.
2. Rebase your worktree onto that commit before coding.
3. Build layout with typed fixtures only after DTO freeze.
4. Keep fixtures behind an explicit development/test adapter.
5. Replace fixtures with live hooks before declaring completion.
6. Do not edit a file currently owned by the backend agent.
7. Commit small frontend-only slices.
8. Before handoff, provide:
   - commit hashes
   - changed-file list
   - DTO/route mismatches
   - typecheck/test results
   - remaining live-verification steps

## Implementation sequence

1. Add `src/api/communicationsCompliance.ts` query keys and typed hooks.
2. Convert `ComplianceView.tsx` into the workspace entry.
3. Build Cases and New Case flow.
4. Build approved-case Conversations with read-only timeline and context rail.
5. Build Access Log.
6. Build export, decision, close, and revoke dialogs.
7. Implement loading/empty/denied/pending/expired/revoked/error/export states.
8. Remove `ComplianceBrowser`, `AccessThreadDialog`, and old compliance hooks
   only after all callers are gone.
9. Add focused frontend tests.
10. Run the final verification gates from the implementation handoff.

## Visual requirements

Use the supplied mockup for information architecture, but implement with the
current Messenger design system and semantic theme tokens. Desktop targets are
1440, 1600, and 1920. Keep body text at least 14px and metadata at least 12px.
No charts, widget board, nested cards, gradients, or separate application shell.

## Final response format

Report:

1. implemented views and flows;
2. exact files changed;
3. contract deviations or blockers;
4. typecheck and test results;
5. whether fixtures are fully removed;
6. browser verification results;
7. commit hash ready for parent-agent integration.

Do not claim done if backend integration or live E2E remains unverified.

---

## How the parent Claude session should use this

1. Keep the backend subagent in its existing backend worktree.
2. Commit/freeze `types/messagingCompliance.ts` and exact route envelopes first.
3. Start a second subagent with worktree isolation enabled.
4. Give that subagent the prompt above and the frozen commit hash.
5. Tell both agents that `types/messagingCompliance.ts` is backend-owned.
6. Let the frontend subagent use fixtures only for layout/component work.
7. Merge backend first.
8. Rebase frontend onto the backend result.
9. Resolve integration only in the frontend branch; do not let both agents
   independently change the shared contract.
10. Run the combined live E2E and browser gates after integration.

If Claude cannot guarantee isolated worktrees for subagents, do not run both
writers concurrently. Run the backend first, then the frontend.
